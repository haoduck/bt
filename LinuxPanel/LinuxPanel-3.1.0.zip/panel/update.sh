#!/bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH

setup_path=/www
wget -T 5 -O panel.zip $1
unzip -o panel.zip -d $setup_path/server/ > /dev/null

rm -f panel.zip
rm -f $setup_patn/server/panel/class/*.pyc
rm -f $setup_patn/server/panel/*.pyc
python -m compileall $setup_patn/server/panel
rm -f $setup_patn/server/panel/class/*.py
rm -f $setup_patn/server/panel/*.py