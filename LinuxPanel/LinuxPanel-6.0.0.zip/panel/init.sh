#!/bin/bash
# chkconfig: 2345 55 25
# description: bt Cloud Service

### BEGIN INIT INFO
# Provides:          bt
# Required-Start:    $all
# Required-Stop:     $all
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# Short-Description: starts bt
# Description:       starts the bt
### END INIT INFO
panel_path=/www/server/panel
pidfile=$panel_path/logs/panel.pid
cd $panel_path
panel_start()
{
		pid=`cat $pidfile`
        isStart=`ps aux|grep $pid|grep -v grep`
        if [ "$isStart" == '' ];then
                echo -e "Starting Bt-Panel... \c"
                if [ -f 'main.py' ];then
                        python -m py_compile main.py
                fi
                gunicorn -c runconfig.py runserver:app
                sleep 0.2
                pid=`cat $pidfile`
                isStart=`ps aux|grep $pid|grep -v grep`
                if [ "$isStart" == '' ];then
                        echo -e "\033[31mfailed\033[0m"
                        echo '------------------------------------------------------'
                        tail -n 20 $panel_path/logs/error.log
                        echo '------------------------------------------------------'
                        echo -e "\033[31mError: BT-Panel service startup failed.\033[0m"
                        return;
                fi
                echo -e "\033[32mdone\033[0m"
        else
                echo "Starting Bt-Panel... Bt-Panel (pid $pid) already running"
        fi
}

panel_stop()
{
        echo -e "Stopping Bt-Panel... \c";
        pid=`cat $pidfile`
        isStart=`ps aux|grep $pid|grep -v grep`
        if [ "$isStart" != '' ];then
        	kill -9 $pid
        else
        	kill -9 `ps aux|grep gunicorn|grep -v grep|awk '{print $2}'`
        fi
        echo -e "\033[32mdone\033[0m"
}

panel_status()
{
        pid=`cat $pidfile`
        isStart=`ps aux|grep $pid|grep -v grep`
        if [ "$isStart" != '' ];then
                echo -e "\033[32mBt-Panel (pid $pid) already running\033[0m"
        else
                echo -e "\033[31mBt-Panel not running\033[0m"
        fi
}

panel_reload()
{
		pid=`cat $pidfile`
        isStart=`ps aux|grep $pid|grep -v grep`
        
        if [ "$isStart" != '' ];then
        		echo -e "Reload Bt-Panel... \c";
                kill -HUP $pid
                isStart=`ps aux|grep $pid|grep -v grep`
                if [ "$isStart" == '' ];then
                        echo -e "\033[31mfailed\033[0m"
                        echo '------------------------------------------------------'
                        cat /tmp/panelBoot.pl
                        echo '------------------------------------------------------'
                        echo -e "\033[31mError: BT-Panel service startup failed.\033[0m"
                        return;
                fi
                echo -e "\033[32mdone\033[0m"
        else
                echo -e "\033[31mBt-Panel not running\033[0m"
                panel_start
        fi
}

install_used()
{
        if [ ! -f $panel_path/aliyun.pl ];then
                return;
        fi
        password=`cat /dev/urandom | head -n 16 | md5sum | head -c 12`
        username=`python $panel_path/tools.py panel $password`
        echo "$password" > $panel_path/default.pl
        rm -f $panel_path/aliyun.pl
}

error_logs()
{
	tail -n 100 $panel_path/logs/error.log
}


case "$1" in
        'start')
                install_used
                panel_start
                ;;
        'stop')
                panel_stop
                ;;
        'restart')
                panel_stop
                sleep 0.2
                panel_start
                ;;
        'reload')
                panel_reload
                ;;
        'status')
                panel_status
                ;;
        'logs')
        	error_logs
        	;;
        'default')
                port=`cat $panel_path/data/port.pl`
                password=`cat $panel_path/default.pl`
                echo -e "=================================================================="
                echo -e "\033[32mBT-Panel default info!\033[0m"
                echo -e "=================================================================="
                echo  "Bt-Panel: http://IP:$port"
                echo -e `python $panel_path/tools.py username`
                echo -e "password: $password"
                echo -e "\033[33mWarning:\033[0m"
                echo -e "\033[33mIf you cannot access the panel, \033[0m"
                echo -e "\033[33mrelease the following port (8888|888|80|443|20|21) in the security group\033[0m"
                echo -e "=================================================================="
                ;;
        *)
                echo "Usage: /etc/init.d/bt {start|stop|restart|reload|logs|default}"
        ;;
esac

